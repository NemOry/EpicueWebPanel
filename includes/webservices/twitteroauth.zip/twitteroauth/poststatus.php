<?php

/* Start session and load library. */
session_start();
require_once("../../initialize.php");

/* Build TwitterOAuth object with client credentials. */
$connection = new TwitterOAuth(CONSUMER_KEY, CONSUMER_SECRET);
 
/* Get temporary credentials. */
$request_token = $connection->getRequestToken(OAUTH_CALLBACK);

$status = $connection->post('statuses/update', array('status' => 'EPICUE TWITTER TEST'));

?>